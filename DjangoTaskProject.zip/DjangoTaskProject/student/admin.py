from django.contrib import admin
from . models import Student

# Register your models here.
#View Student register data in Admin Panel
class StudentView(admin.ModelAdmin):
	list_display = [
			'fname',
			'lname',
			'branch',
			'email',
			'date',
			'mobile'
	]
	search_fields = ('fname','branch','mobile' )
	list_filter = ('fname', 'branch', 'mobile')

admin.site.register(Student, StudentView)