from django.db import models

# Create your models here.
class Student(models.Model):
	fname = models.CharField(max_length=30, null=False)
	lname = models.CharField(max_length=30, null=False)
	branch = models.CharField(max_length=30)
	email = models.EmailField(null=False)
	mobile = models.CharField(max_length=12,null=False)
	date = models.DateField()
