from django.contrib import admin
from . models import Teacher

# Register your models here.
# View Teacher register data in Admin Panel
class RegistrationView(admin.ModelAdmin):
	list_display =[

	              'fname',
	              'lname',
	              'email',
	              'mobile',
	              'date'

	]

admin.site.register(Teacher, RegistrationView)
