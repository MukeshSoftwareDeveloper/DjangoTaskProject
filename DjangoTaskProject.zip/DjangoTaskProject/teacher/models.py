from django.db import models

# Create your models here.
class Teacher(models.Model):
	fname = models.CharField(max_length=30, null=False)
	lname = models.CharField(max_length=30, null=False)
	email = models.EmailField(null=False)
	mobile = models.CharField(max_length=50,null=False)
	date = models.DateField()
