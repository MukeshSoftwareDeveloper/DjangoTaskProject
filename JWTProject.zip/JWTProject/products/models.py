from django.db import models

# Create your models here.
class Products(models.Model):
	pname =  models.CharField(max_length=30, null=False)
	pbrand = models.CharField(max_length=30, null=False)
	price =  models.CharField(max_length=30, null=False)
	pqty =  models.IntegerField()
 